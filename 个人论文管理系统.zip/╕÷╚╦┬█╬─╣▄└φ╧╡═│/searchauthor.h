#ifndef SEARCHAUTHOR_H
#define SEARCHAUTHOR_H

#include <QMainWindow>

namespace Ui {
class searchAuthor;
}

class searchAuthor : public QMainWindow
{
    Q_OBJECT

public:
    explicit searchAuthor(QWidget *parent = 0);
    ~searchAuthor();

private slots:
    void on_pushButton_ayuthor_clicked();

    void on_pushButton_author_clicked();

    void on_pushButton_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::searchAuthor *ui;
};

#endif // SEARCHAUTHOR_H
