#ifndef FUZZYSEARCHAUTHOR_H
#define FUZZYSEARCHAUTHOR_H

#include <QMainWindow>

namespace Ui {
class fuzzysearchauthor;
}

class fuzzysearchauthor : public QMainWindow
{
    Q_OBJECT

public:
    explicit fuzzysearchauthor(QWidget *parent = 0);
    ~fuzzysearchauthor();

private slots:
    void on_pushButton_exit_clicked();

    void on_pushButton_clicked();

private:
    Ui::fuzzysearchauthor *ui;
};

#endif // FUZZYSEARCHAUTHOR_H
