#ifndef FUZZYSEARCHYEAR_H
#define FUZZYSEARCHYEAR_H

#include <QMainWindow>

namespace Ui {
class fuzzysearchyear;
}

class fuzzysearchyear : public QMainWindow
{
    Q_OBJECT

public:
    explicit fuzzysearchyear(QWidget *parent = 0);
    ~fuzzysearchyear();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::fuzzysearchyear *ui;
};

#endif // FUZZYSEARCHYEAR_H
