#ifndef SEARCHNAME_H
#define SEARCHNAME_H

#include <QMainWindow>

namespace Ui {
class searchName;
}

class searchName : public QMainWindow
{
    Q_OBJECT

public:
    explicit searchName(QWidget *parent = 0);
    ~searchName();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::searchName *ui;
};

#endif // SEARCHNAME_H
