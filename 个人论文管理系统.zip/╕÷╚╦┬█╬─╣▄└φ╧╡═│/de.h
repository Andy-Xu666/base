#ifndef DE_H
#define DE_H

#include <QMainWindow>

namespace Ui {
class de;
}

class de : public QMainWindow
{
    Q_OBJECT

public:
    explicit de(QWidget *parent = 0);
    ~de();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::de *ui;
};

#endif // DE_H
