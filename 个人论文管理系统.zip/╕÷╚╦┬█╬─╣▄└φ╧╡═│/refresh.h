#ifndef REFRESH_H
#define REFRESH_H

#include <QMainWindow>

namespace Ui {
class refresh;
}

class refresh : public QMainWindow
{
    Q_OBJECT

public:
    explicit refresh(QWidget *parent = 0);
    ~refresh();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::refresh *ui;
};

#endif // REFRESH_H
