#include "search.h"
#include "ui_search.h"
#include<Qstring>
#include"QLineEdit"
#include<iostream>
#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>
using namespace std;
Search::Search(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Search)
{
    ui->setupUi(this);
}

Search::~Search()
{
    delete ui;
}

void Search::on_pushButton_exit_clicked()
{
    close();
}


void Search::on_pushButton_name_clicked()
{
    sn =new searchName;
    sn->show();

}

void Search::on_pushButton_year_clicked()
{
    sy=new searchyear;
    sy->show();

}


void Search::on_pushButton_meeting_clicked()
{
    sm=new searchmeeting;
    sm->show();

}

void Search::on_pushButton_author_clicked()
{
    sa=new searchAuthor;
    sa->show();
}

