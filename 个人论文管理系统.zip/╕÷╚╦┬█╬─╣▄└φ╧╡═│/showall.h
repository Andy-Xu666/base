#ifndef SHOWALL_H
#define SHOWALL_H

#include <QMainWindow>

namespace Ui {
class showall;
}

class showall : public QMainWindow
{
    Q_OBJECT

public:
    explicit showall(QWidget *parent = 0);
    ~showall();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_sort_clicked();

    void on_pushButton_show_clicked();

private:
    Ui::showall *ui;
};

#endif // SHOWALL_H
