#include "searchmeeting.h"
#include "ui_searchmeeting.h"
#include<Qstring>
#include"QLineEdit"
#include<iostream>
#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>
searchmeeting::searchmeeting(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::searchmeeting)
{
    ui->setupUi(this);
}

searchmeeting::~searchmeeting()
{
    delete ui;
}
int mThan(const QString s1, const QString s2)
{
    QString  str1;
    str1 = s1.section(' ',2,2);
    return str1 ==s2;
}

void searchmeeting::on_pushButton_clicked()
{
    ui->listWidget->clear();
    QFile dataFile("C:/Users/Lenovo/Desktop/QT.txt");
    if (dataFile.open(QFile::ReadOnly|QIODevice::Text))
    {
        QTextStream data(&dataFile);
        QStringList fonts;
        QString line;
        while (!data.atEnd())//逐行读取文本，并去除每行的回车
        {
            line = data.readLine();
            line.remove('\n');
            if(mThan(line, ui->lineEdit->text())){
                fonts<<line;
            }
        }
        ui->listWidget->addItems(fonts);//把各行添加到listwidget
    }
}

void searchmeeting::on_pushButton_exit_clicked()
{
    close();
}
