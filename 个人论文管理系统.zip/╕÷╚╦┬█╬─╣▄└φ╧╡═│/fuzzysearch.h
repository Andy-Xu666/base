#ifndef FUZZYSEARCH_H
#define FUZZYSEARCH_H

#include <QMainWindow>
#include<fuzzysearchauthor.h>
#include<fuzzysearchmeeting.h>
#include<fuzzysearchname.h>
#include<fuzzysearchyear.h>
namespace Ui {
class fuzzysearch;
}

class fuzzysearch : public QMainWindow
{
    Q_OBJECT

public:
    explicit fuzzysearch(QWidget *parent = 0);
    ~fuzzysearch();

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_author_clicked();

    void on_pushButton_year_clicked();

    void on_pushButton_name_clicked();

    void on_pushButton_meeting_clicked();

private:
    Ui::fuzzysearch *ui;
    fuzzysearchauthor *fa;
    fuzzysearchmeeting *fm;
    fuzzysearchname *fn;
    fuzzysearchyear *fy;
};

#endif // FUZZYSEARCH_H
