#include "searchauthor.h"
#include "ui_searchauthor.h"
#include<Qstring>
#include"QLineEdit"
#include<iostream>
#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>
#include<iostream>
using namespace std;
searchAuthor::searchAuthor(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::searchAuthor)
{
    ui->setupUi(this);
}

searchAuthor::~searchAuthor()
{
    delete ui;
}
int aThan(const QString s1, const QString s2)
{
    QString  str1;
    str1 = s1.section(' ',1,1);
    return str1 ==s2;
}


//查找姓名
void searchAuthor::on_pushButton_clicked()
{
    ui->listWidget->clear();
    QFile dataFile("C:/Users/Lenovo/Desktop/QT.txt");
    if (dataFile.open(QFile::ReadOnly|QIODevice::Text))
    {
        QTextStream data(&dataFile);
        QStringList fonts;
        QString line;
        while (!data.atEnd())//逐行读取文本，并去除每行的回车
        {
            line = data.readLine();
            line.remove('\n');
            if(aThan(line, ui->lineEdit->text())){
                fonts<<line;
            }
        }
        ui->listWidget->addItems(fonts);//把各行添加到listwidget
    }
}

void searchAuthor::on_pushButton_exit_clicked()
{
    close();
}
