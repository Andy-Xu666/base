#ifndef FUZZYSEARCHMEETING_H
#define FUZZYSEARCHMEETING_H

#include <QMainWindow>

namespace Ui {
class fuzzysearchmeeting;
}

class fuzzysearchmeeting : public QMainWindow
{
    Q_OBJECT

public:
    explicit fuzzysearchmeeting(QWidget *parent = 0);
    ~fuzzysearchmeeting();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::fuzzysearchmeeting *ui;
};

#endif // FUZZYSEARCHMEETING_H
