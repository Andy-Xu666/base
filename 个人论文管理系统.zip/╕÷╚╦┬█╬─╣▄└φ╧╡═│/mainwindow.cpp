#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_exit_clicked()
{
    close();
}

void MainWindow::on_pushButton_search_clicked()
{
    a=new Search;
    a->show();
}

void MainWindow::on_pushButton_FuzzySearch_clicked()
{
    fu=new fuzzysearch;
    fu->show();
}


void MainWindow::on_pushButton_delete_clicked()
{
    d =new de;
    d->show();
}



void MainWindow::on_pushButton_showall_clicked()
{
    sh =new showall;
    sh->show();
}



void MainWindow::on_pushButton_add_clicked()
{
    ad=new add;
    ad->show();
}

void MainWindow::on_pushButton_clicked()
{
    r =new refresh;
    r->show();

}
