#include "refresh.h"
#include "ui_refresh.h"
#include <QMessageBox>
#include <QFileDialog>

#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>

refresh::refresh(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::refresh)
{
    ui->setupUi(this);
}

refresh::~refresh()
{
    delete ui;
}
int raThan(const QString s1, const QString s2)
{
    QString  str1;
    str1 = s1.section(' ',0,0);
    return str1 ==s2;
}
//更新
void refresh::on_pushButton_2_clicked()
{

    QString strAll;
    QStringList strList;
    QFile readFile("C:/Users/Lenovo/Desktop/QT.txt");
    if(readFile.open((QIODevice::ReadOnly|QIODevice::Text)))
    {
         QTextStream stream(&readFile);
         strAll=stream.readAll();
    }
     readFile.close();
     QFile writeFile("C:/Users/Lenovo/Desktop/QT.txt");
     if(writeFile.open(QIODevice::WriteOnly|QIODevice::Text))
     {
             QTextStream stream(&writeFile);
             strList=strAll.split("\n");
             for(int i=0;i<strList.count();i++)
             {
                 if(i==strList.count()-1)
                 {
                     //最后一行不需要换行
                     stream<<strList.at(i);
                 }
                 else if(raThan(strList.at(i),ui->lineEdit_name->text()))
                 {
                     QString tempStr=strList.at(i);
                     tempStr.replace(0,tempStr.length(),ui->lineEdit_name->text()+" "+ ui->lineEdit_author->text()+" "+  ui->lineEdit_meeting->text()+" "+ui->lineEdit_year->text()+" "+ ui->lineEdit_link->text());

                     stream<<tempStr<<'\n';

                 }
                 else
                 {
                     stream<<strList.at(i)<<'\n';
                 }
             }
     }
     writeFile.close();
}

void refresh::on_pushButton_3_clicked()
{
    close();
}
