#include "de.h"
#include "ui_de.h"
#include <QMessageBox>
#include <QFileDialog>

#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>
de::de(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::de)
{
    ui->setupUi(this);
}

de::~de()
{
    delete ui;
}

void de::on_pushButton_clicked()
{
    close();
}

int daThan(const QString s1, const QString s2)
{
    QString  str1;
    str1 = s1.section(' ',0,0);
    return str1 ==s2;
}
//删除
void de::on_pushButton_2_clicked()
{
    QString strAll;
    QStringList strList;
    QFile readFile("C:/Users/Lenovo/Desktop/QT.txt");
    if(readFile.open((QIODevice::ReadOnly|QIODevice::Text)))
    {
         QTextStream stream(&readFile);
         strAll=stream.readAll();
    }
     readFile.close();
     QFile writeFile("C:/Users/Lenovo/Desktop/QT.txt");
     if(writeFile.open(QIODevice::WriteOnly|QIODevice::Text))
     {
             QTextStream stream(&writeFile);
             strList=strAll.split("\n");
             for(int i=0;i<strList.count();i++)
             {
                 if(i==strList.count()-1)
                 {
                     if(daThan(strList.at(i), ui->lineEdit_delete->text()))
                     {
                         i=i;
                     }
                     //最后一行不需要换行
                     else
                     {
                         stream<<strList.at(i);
                     }
                 }
                 else if(daThan(strList.at(i), ui->lineEdit_delete->text()))
                 {
                     i=i;
                 }
                 else
                 {
                     stream<<strList.at(i)<<'\n';
                 }
             }
     }
     writeFile.close();
     ui->lineEdit_delete->clear();
}
