#include "showall.h"
#include "ui_showall.h"
#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>
#include <QVector>
#include <ctime>
#include <QDebug>
#include<paper.h>
#include<iostream>
using namespace std;

showall::showall(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::showall)
{
    ui->setupUi(this);
}

showall::~showall()
{
    delete ui;
}

void showall::on_pushButton_clicked()
{
    close();
}


//显示所有数据
void showall::on_pushButton_2_clicked()
{
    ui->listWidget->clear();
    //QFile dataFile("C:/Users/Lenovo/Desktop/QT1.txt");
    QFile dataFile("C:/Users/Lenovo/Desktop/QT.txt");
    if (dataFile.open(QFile::ReadOnly|QIODevice::Text))
    {
        QTextStream data(&dataFile);
        QStringList fonts;
        QString line;
        while (!data.atEnd())//逐行读取文本，并去除每行的回车
        {
            line = data.readLine();
            line.remove('\n');
            fonts<<line;
        }
        ui->listWidget->addItems(fonts);//把各行添加到listwidget
    }
}
bool intThan(const QString &s1, const QString &s2)
{
    QString  str1,str2;
    str1 = s1.section(' ',3,3);
    int temp1=str1.toInt();
    str2 = s2.section(' ',3,3);
    int temp2 = str2.toInt();
    return str1<str2;
}
//排序


void showall::on_pushButton_sort_clicked()
{
   /*QString strAll;
   QStringList strList;
   QFile readFile("C:/Users/Lenovo/Desktop/QT1.txt");
    if(readFile.open((QIODevice::ReadOnly|QIODevice::Text)))
    {
         QTextStream stream(&readFile);
         strAll=stream.readAll();
    }
     readFile.close();
     strList=strAll.split("\n");
     qSort(strList.begin(),strList.end(),intThan);
     QFile writeFile("C:/Users/Lenovo/Desktop/QT1.txt");
     if(writeFile.open(QIODevice::WriteOnly|QIODevice::Text))
     {
             QTextStream stream(&writeFile);
             for(int i=0;i<strList.count();i++)
             {
                 if(i==strList.count()-1)
                 {
                     //最后一行不需要换行
                     stream<<strList.at(i);
                 }
                 else
                 {
                     stream<<strList.at(i)<<'\n';
                 }
             }
     }
     writeFile.close();*/

    Paper pa[50];
    int count=0;
    QFile dataFile("C:/Users/Lenovo/Desktop/QT.txt");
    if (dataFile.open(QFile::ReadOnly|QIODevice::Text))
    {

        QTextStream data(&dataFile);
        QStringList fonts;
        QString line;
        while (!data.atEnd())//逐行读取文本，并去除每行的回车
        {
            line = data.readLine();
            line.remove('\n');
            pa[count].n=line.section(" ",0,0);
            pa[count].a=line.section(" ",1,1);
            pa[count].m=line.section(" ",2,2);
            pa[count].y=line.section(" ",3,3).toInt();
            pa[count].l=line.section(" ",4,4);
            count++;
        }
    }
    int i,j,m;
    Paper x;      //i,j均为循环变量，x用来存储当前待排序的数据，m充当比较区间的中点
    int low,high;     //low代表要与x[i]进行比较的有序区间的第一个元素所在位置。high代表要与x[i]进行比较的有序区间的最后一个元素所在位置。
    for (i = 1; i < count; i++)
    {
        x = pa[i];
        low = 0;  high = i-1;   //第一次划分有序比较区间，比较区间的最后一个元素所在位置为n-1
        //比较查找x[i]合适插入的位置
        while (low <= high)
        {
            m = (low + high)/2;


            if (x.y >= pa[m].y)
            {
                low = m+1;
            }
            else
            {
                high = m-1;
            }
        }
        //确定好位置后，将位置之后的数据后移，插入待排序数据
        for (j = i-1;j > high; j--)
        {
            pa[j+1] = pa[j];
        }
        pa[j+1] = x;
    }
    /*for(int i=1; i<count; i++){
        if(pa[i].y<pa[i-1].y){ // 如果当前数比前一个数小
            Paper cur = pa[i]; // 把当前数记录下来
            int j = i - 1; // 用j来记录当前数的前一个数的下标
            for(; j>=0&&cur.y<pa[j].y; j--){
                pa[j+1] = pa[j];
            }
            pa[++j] = cur; // j要记得++
        }
    }*/

    QFile writeFile("C:/Users/Lenovo/Desktop/QT.txt");
    if(writeFile.open(QIODevice::WriteOnly|QIODevice::Text))
    {
        QTextStream stream(&writeFile);
        for(int i=0;i<count;i++)
        {
            if(i==count-1)
            {
                //最后一行不需要换行
                stream<<pa[i].n<<" "<<pa[i].a<<" "<<pa[i].m<<" "<<pa[i].y<<" "<<pa[i].l<<"\n";
            }
            else
            {
                stream<<pa[i].n<<" "<<pa[i].a<<" "<<pa[i].m<<" "<<pa[i].y<<" "<<pa[i].l<<"\n";
                //stream<<strList.at(i)<<'\n';
            }
        }
    }
    writeFile.close();
}

void showall::on_pushButton_show_clicked()
{
    close();
}
