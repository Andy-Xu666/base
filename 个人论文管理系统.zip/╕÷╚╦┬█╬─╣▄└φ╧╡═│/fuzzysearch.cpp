#include "fuzzysearch.h"
#include "ui_fuzzysearch.h"
#include<iostream>
#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>
fuzzysearch::fuzzysearch(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::fuzzysearch)
{
    ui->setupUi(this);
}

fuzzysearch::~fuzzysearch()
{
    delete ui;
}




void fuzzysearch::on_pushButton_3_clicked()
{
    close();
}

void fuzzysearch::on_pushButton_author_clicked()
{
    fa=new fuzzysearchauthor;
    fa->show();
}

void fuzzysearch::on_pushButton_year_clicked()
{
    fy=new fuzzysearchyear;
    fy->show();
}

void fuzzysearch::on_pushButton_name_clicked()
{
    fn=new fuzzysearchname;
    fn->show();

}

void fuzzysearch::on_pushButton_meeting_clicked()
{
    fm=new fuzzysearchmeeting;
    fm->show();
}
