#include "fuzzysearchmeeting.h"
#include "ui_fuzzysearchmeeting.h"
#include<Qstring>
#include"QLineEdit"
#include<iostream>
#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>
#include<iostream>
fuzzysearchmeeting::fuzzysearchmeeting(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::fuzzysearchmeeting)
{
    ui->setupUi(this);
}

fuzzysearchmeeting::~fuzzysearchmeeting()
{
    delete ui;
}
void fuzzysearchmeeting::on_pushButton_clicked()
{
    ui->listWidget->clear();
    QFile dataFile("C:/Users/Lenovo/Desktop/QT.txt");
    if (dataFile.open(QFile::ReadOnly|QIODevice::Text))
    {
        QTextStream data(&dataFile);
        QStringList fonts;
        QString line;
        while (!data.atEnd())//逐行读取文本，并去除每行的回车
        {
            line = data.readLine();
            line.remove('\n');
            if(line.section(" ",2,2).contains(ui->lineEdit->text())){
                fonts<<line;
            }
        }
        ui->listWidget->addItems(fonts);//把各行添加到listwidget
    }
}

void fuzzysearchmeeting::on_pushButton_exit_clicked()
{
    close();
}
