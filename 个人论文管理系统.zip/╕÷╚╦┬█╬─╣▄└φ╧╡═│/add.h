#ifndef ADD_H
#define ADD_H

#include <QMainWindow>
#include<QJsonArray>
#include<QJsonObject>
#include<QJsonDocument>
#include<QByteArray>
#include<QDebug>
#include<QJsonParseError>
namespace Ui {
class add;
}

class add : public QMainWindow
{
    Q_OBJECT

public:
    explicit add(QWidget *parent = 0);
    ~add();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::add *ui;
};

#endif // ADD_H
