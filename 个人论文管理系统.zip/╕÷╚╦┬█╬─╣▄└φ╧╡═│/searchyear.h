#ifndef SEARCHYEAR_H
#define SEARCHYEAR_H

#include <QMainWindow>

namespace Ui {
class searchyear;
}

class searchyear : public QMainWindow
{
    Q_OBJECT

public:
    explicit searchyear(QWidget *parent = 0);
    ~searchyear();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::searchyear *ui;
};

#endif // SEARCHYEAR_H
