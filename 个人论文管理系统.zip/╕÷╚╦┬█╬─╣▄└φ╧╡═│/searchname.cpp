#include "searchname.h"
#include "ui_searchname.h"
#include<Qstring>
#include"QLineEdit"
#include<iostream>
#include <QString>
#include <QStringList>
#include <QFile>
#include <QTextStream>
searchName::searchName(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::searchName)
{
    ui->setupUi(this);
}

searchName::~searchName()
{
    delete ui;
}
int Than(const QString s1, const QString s2)
{
    QString  str1;
    str1 = s1.section(' ',0,0);
    return str1 ==s2;
}


void searchName::on_pushButton_clicked()
{
    ui->textBrowser->clear();
    QString strAll;
    QStringList strList;
    QFile readFile("C:/Users/Lenovo/Desktop/QT.txt");
    if(readFile.open((QIODevice::ReadOnly|QIODevice::Text)))
    {
        QTextStream stream(&readFile);
        strAll=stream.readAll();
    }
    readFile.close();
    strList=strAll.split("\n");
    for(int i=0;i<strList.count();i++)
    {
        if(Than(strList.at(i), ui->lineEdit->text()))
        {
            ui->textBrowser->setText(strList.at(i));
        }
    }
}

void searchName::on_pushButton_exit_clicked()
{
    close();
}
