#include "paper.h"

Paper::Paper()
{

}
