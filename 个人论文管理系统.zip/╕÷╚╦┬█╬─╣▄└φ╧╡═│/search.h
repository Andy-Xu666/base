#ifndef SEARCH_H
#define SEARCH_H
#include<searchauthor.h>
#include<searchmeeting.h>
#include<searchname.h>
#include<searchyear.h>
#include <QMainWindow>

namespace Ui {
class Search;
}

class Search : public QMainWindow
{
    Q_OBJECT

public:
    explicit Search(QWidget *parent = 0);
    ~Search();

private slots:
    void on_pushButton_exit_clicked();

    void on_lineEdit_author_cursorPositionChanged(int arg1, int arg2);

    void on_pushButton_name_clicked();

    void on_pushButton_year_clicked();

    void on_pushButton_search_clicked();

    void on_pushButton_meeting_clicked();

    void on_pushButton_author_clicked();

    void on_pushButton_clicked();

private:
    Ui::Search *ui;
    searchAuthor *sa;
    searchmeeting *sm;
    searchName *sn;
    searchyear *sy;
};

#endif // SEARCH_H
