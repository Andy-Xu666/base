#ifndef PAPER_H
#define PAPER_H
#include <QMainWindow>

class Paper
{
public:
    Paper();
    QString a;
    QString n;
    QString l;
    QString m;
    int y;
};

#endif // PAPER_H
