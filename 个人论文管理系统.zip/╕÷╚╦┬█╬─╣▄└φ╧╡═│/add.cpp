#include "add.h"
#include "ui_add.h"
#include <QMessageBox>
#include <QFileDialog>

add::add(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::add)
{
    ui->setupUi(this);
}

add::~add()
{
    delete ui;
}

void add::on_pushButton_clicked()
{
    close();
}
//插入
void add::on_pushButton_2_clicked()
{
    QString a,m,l,y,n;
    a=ui->lineEdit_author->text();
    l=ui->lineEdit_link->text();
    m=ui->lineEdit_meeting->text();
    y=ui->lineEdit_year->text();
    n=ui->lineEdit_name->text();

    QFile file("C:/Users/Lenovo/Desktop/QT.txt");
    file.open( QIODevice::ReadWrite | QIODevice::Append);
    QTextStream out(&file);
    if(!ui->lineEdit_author->text().isEmpty() && !ui->lineEdit_link->text().isEmpty()&& !ui->lineEdit_meeting->text().isEmpty()&& !ui->lineEdit_name->text().isEmpty()&& !ui->lineEdit_year->text().isEmpty()){
        out << ui->lineEdit_name->text();
        out << " ";
        out << ui->lineEdit_author->text();
        out << " ";
        out << ui->lineEdit_meeting->text();
        out << " ";
        out << ui->lineEdit_year->text();
        out << " ";
        out << ui->lineEdit_link->text();
        out << "\n";
      }
    file.close();
    ui->lineEdit_author->clear();
    ui->lineEdit_link->clear();;
    ui->lineEdit_meeting->clear();;
    ui->lineEdit_name->clear();
    ui->lineEdit_year->clear();
}
