#ifndef FUZZYSEARCHNAME_H
#define FUZZYSEARCHNAME_H

#include <QMainWindow>

namespace Ui {
class fuzzysearchname;
}

class fuzzysearchname : public QMainWindow
{
    Q_OBJECT

public:
    explicit fuzzysearchname(QWidget *parent = 0);
    ~fuzzysearchname();

private slots:
    void on_pushButton_exit_clicked();

    void on_pushButton_clicked();

private:
    Ui::fuzzysearchname *ui;
};

#endif // FUZZYSEARCHNAME_H
