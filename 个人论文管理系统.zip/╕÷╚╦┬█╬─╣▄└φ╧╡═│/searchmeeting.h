#ifndef SEARCHMEETING_H
#define SEARCHMEETING_H

#include <QMainWindow>

namespace Ui {
class searchmeeting;
}

class searchmeeting : public QMainWindow
{
    Q_OBJECT

public:
    explicit searchmeeting(QWidget *parent = 0);
    ~searchmeeting();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::searchmeeting *ui;
};

#endif // SEARCHMEETING_H
